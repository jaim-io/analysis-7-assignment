// Jamey Schaap 0950044
// Vincent de Gans 1003196

namespace TheCardGame.Effects.Types;

public class PreRevealEffect : EffectType
{
    public override string Name { get; init; } = "PreRevealEffect";
}