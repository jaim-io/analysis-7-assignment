// Jamey Schaap 0950044
// Vincent de Gans 1003196

namespace TheCardGame.Effects.Types;

public abstract class EffectType
{
    public abstract string Name { get; init; }
}