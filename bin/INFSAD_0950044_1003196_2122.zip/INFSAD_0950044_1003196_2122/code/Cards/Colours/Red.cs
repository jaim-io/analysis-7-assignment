// Jamey Schaap 0950044
// Vincent de Gans 1003196

namespace TheCardGame.Cards.Colours;

public class Red : Colour
{
    public Red(int cost)
        : base(nameof(Red), cost)
    {
    }
}