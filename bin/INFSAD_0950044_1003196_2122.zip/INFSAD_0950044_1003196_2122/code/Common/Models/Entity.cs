// Jamey Schaap 0950044
// Vincent de Gans 1003196

namespace TheCardGame.Common.Models;

public abstract class Entity
{
}