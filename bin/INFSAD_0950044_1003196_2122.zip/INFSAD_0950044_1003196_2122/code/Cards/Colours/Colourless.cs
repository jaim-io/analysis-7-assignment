// Jamey Schaap 0950044
// Vincent de Gans 1003196

namespace TheCardGame.Cards.Colours;

public class Colourless : Colour
{
    public Colourless(int cost)
        : base(nameof(Colourless), cost)
    {
    }
}